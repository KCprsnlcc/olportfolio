<?php
$hostname = 'localhost'; // Change this to your database host
$username = 'your_db_username'; // Change this to your database username
$password = 'your_db_password'; // Change this to your database password
$database = 'your_database_name'; // Change this to your database name

$connection = new mysqli($hostname, $username, $password, $database);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Set character set to UTF-8 (optional, but recommended)
if (!$connection->set_charset("utf8")) {
    die("Error loading character set utf8: " . $connection->error);
}
